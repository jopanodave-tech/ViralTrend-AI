export default function Home() {
  return (
    <main style={{padding:'40px',fontFamily:'sans-serif'}}>
      <h1>ViralTrend AI</h1>
      <p>Find viral content before everyone else.</p>
    </main>
  );
}
