export async function POST(req: Request) {
  const { topic } = await req.json();

  return Response.json({
    topic,
    ideas: [
      "Viral idea 1",
      "Viral idea 2",
      "Viral idea 3"
    ]
  });
}
